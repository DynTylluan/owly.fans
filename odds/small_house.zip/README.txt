===========================================================================
Title                   : Small House
Filename                : small_house.zip
Release date            : 2023-04-13
Author                  : Cass "Owly" Python
Email Address           : owlgal69@protonmail.com
Misc. Author Info       : My website: https://owly.fans

Description             : A small house that I made after seeing the linked
                          URL. I think it kind of looks like a watchtower.
                          https://redd.it/12k5hhx
                          
                          The flags used here are the St Andrew's Cross (flag
                          of Scotland) and the flag of Saint David.
                          
                          All made in creative.

Additional Credits to   : r27mann for the inspiration.
===========================================================================
* What is included *

New levels              : One
Sounds                  : No
Music                   : No
Graphics                : No
Other                   : No
Other files required    : None


* Construction *

Base                    : New from scratch
Build Time              : Around an hour and a half
May Not Run With        : Anything pre-1.19.3
Tested With             : 1.19.3


* Copyright / Permissions *

This work is licensed under the the Freedom Owl Public License MDP
https://owly.fns/license/mdp

* Where to get the file that this text file describes *

Web sites: https://owly.fans/odds/small_house.zip
