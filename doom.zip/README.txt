===========================================================================
Title                   : Cass' Doom Collection
Filename                : doom.zip
Release date            : 2023-04-13
Author                  : See README for each WAD/port.

Description             : Hello there, young Internet search astronaut!
                          You have found my personal Doom file, good for you!
                          The idea of this ZIP is that if I'm ever on someone
                          else's computer, or at a library computer, I can
                          quickly download the tools needed to be able to
                          play Doom as quickly as possible. This includes
                          also being able to send other people this URL as
                          it's quite short and easy to remember.
                          
                          Have fun killing monsters!
                          - Cass

===========================================================================
* Copyright / Permissions *

While making this collection of Doom WADs and IWADs, I ensured each one was
under a creative license. Not every mod here is under the exact same
license, so please make sure that you have a look at the README file for
each before sharing and modding.

This text file that you're reading is under CC0, if that matters.

* Where to get the file that this text file describes *

Web sites: https://owly.fans/doom.zip (main)
           https://techcat.dev/doom.zip (mirror)