https://owly.fans/doom.zip

Hello there, young Internet search astronaut!
You have found my personal Doom file, good for you! The idea of this ZIP is that if I'm
ever on someone else's computer, or at a library computer, I can quickly download the
tools needed to be able to play Doom as quickly as possible. This includes also being
able to send other people this URL as it's quite short and easy to remember.

Have fun killing monsters!
- Cass